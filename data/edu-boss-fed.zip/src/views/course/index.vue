<template>
  <div class="course">课程管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'CourseIndex'
})
</script>

<style lang="scss" scoped></style>
