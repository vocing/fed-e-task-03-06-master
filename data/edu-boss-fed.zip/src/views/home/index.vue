<template>
  <div class="home">首页</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'HomeIndex'
})
</script>

<style lang="scss" scoped></style>
